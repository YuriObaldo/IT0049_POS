<?php

namespace App\Controllers;

use App\Models\UserModel;

class Users extends BaseController
{
    public function index(): string
    {
        $model = new UserModel();

        try {
            $users = $model->orderBy('username', 'ASC')->findAll();
        } catch (\Throwable $e) {
            log_message('error', 'Unable to load users: ' . $e->getMessage());
            $users = [];
        }

        return view('users', [
            'title' => 'User Accounts',
            'users' => $users,
        ]);
    }
}
