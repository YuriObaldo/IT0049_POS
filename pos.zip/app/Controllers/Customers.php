<?php

namespace App\Controllers;

use App\Models\CustomerModel;

class Customers extends BaseController
{
    public function index(): string
    {
        $model = new CustomerModel();

        try {
            $customers = $model->orderBy('full_name', 'ASC')->findAll();
        } catch (\Throwable $e) {
            log_message('error', 'Unable to load customers: ' . $e->getMessage());
            $customers = [];
        }

        return view('customers', [
            'title' => 'Customer Accounts',
            'customers' => $customers,
        ]);
    }
}
