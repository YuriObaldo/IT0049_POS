<?= $this->include('layouts/header') ?>
<section class="card">
    <h2>About this POS</h2>
    <p>This first version provides a simple foundation for point-of-sale account management.</p>
    <p>Customer and staff records are stored in the application database so account data is persistent and easier to maintain.</p>
</section>
<?= $this->include('layouts/footer') ?>
