<?= $this->include('layouts/header') ?>
<section class="card">
    <h2>User Accounts</h2>
    <p>Staff records are loaded from the application database.</p>
    <table>
        <thead>
            <tr>
                <th>Username</th>
                <th>Full name</th>
                <th>Created at</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= esc($user['username']) ?></td>
                    <td><?= esc($user['full_name']) ?></td>
                    <td><?= esc($user['created_at']) ?></td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</section>
<?= $this->include('layouts/footer') ?>
