<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PosDataSeeder extends Seeder
{
    public function run(): void
    {
        $customers = [
            ['full_name' => 'Maria Santos', 'email' => 'maria.santos@example.com', 'phone' => '(555) 010-1001', 'created_at' => '2026-10-01 09:00:00'],
            ['full_name' => 'James Carter', 'email' => 'james.carter@example.com', 'phone' => '(555) 010-1002', 'created_at' => '2026-10-02 09:00:00'],
            ['full_name' => 'Aisha Rahman', 'email' => 'aisha.rahman@example.com', 'phone' => '(555) 010-1003', 'created_at' => '2026-10-03 09:00:00'],
            ['full_name' => 'Daniel Kim', 'email' => 'daniel.kim@example.com', 'phone' => '(555) 010-1004', 'created_at' => '2026-10-04 09:00:00'],
            ['full_name' => 'Sofia Garcia', 'email' => 'sofia.garcia@example.com', 'phone' => '(555) 010-1005', 'created_at' => '2026-10-05 09:00:00'],
        ];

        $users = [
            ['username' => 'maria.santos', 'full_name' => 'Maria Santos', 'created_at' => '2026-10-01 09:00:00'],
            ['username' => 'james.carter', 'full_name' => 'James Carter', 'created_at' => '2026-10-02 09:00:00'],
            ['username' => 'aisha.rahman', 'full_name' => 'Aisha Rahman', 'created_at' => '2026-10-03 09:00:00'],
            ['username' => 'daniel.kim', 'full_name' => 'Daniel Kim', 'created_at' => '2026-10-04 09:00:00'],
            ['username' => 'sofia.garcia', 'full_name' => 'Sofia Garcia', 'created_at' => '2026-10-05 09:00:00'],
        ];

        $this->db->table('customers')->insertBatch($customers);
        $this->db->table('users')->insertBatch($users);
    }
}
