<?php

use App\Models\CustomerModel;
use App\Models\UserModel;
use CodeIgniter\Test\CIUnitTestCase;

final class DatabaseModelsTest extends CIUnitTestCase
{
    private function seedCustomerAndUserTables(): void
    {
        $db = db_connect();
        $customersTable = $db->prefixTable('customers');
        $usersTable = $db->prefixTable('users');

        $db->query('DROP TABLE IF EXISTS ' . $customersTable);
        $db->query('DROP TABLE IF EXISTS ' . $usersTable);

        $db->query('CREATE TABLE ' . $customersTable . ' (id INT AUTO_INCREMENT PRIMARY KEY, full_name VARCHAR(100) NOT NULL, email VARCHAR(100) NOT NULL, phone VARCHAR(20), created_at DATETIME NOT NULL)');
        $db->query('CREATE TABLE ' . $usersTable . ' (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE, full_name VARCHAR(100) NOT NULL, created_at DATETIME NOT NULL)');

        $db->table('customers')->insertBatch([
            ['full_name' => 'Maria Santos', 'email' => 'maria.santos@example.com', 'phone' => '(555) 010-1001', 'created_at' => '2026-10-01 09:00:00'],
            ['full_name' => 'James Carter', 'email' => 'james.carter@example.com', 'phone' => '(555) 010-1002', 'created_at' => '2026-10-02 09:00:00'],
        ]);

        $db->table('users')->insertBatch([
            ['username' => 'maria.santos', 'full_name' => 'Maria Santos', 'created_at' => '2026-10-01 09:00:00'],
            ['username' => 'james.carter', 'full_name' => 'James Carter', 'created_at' => '2026-10-02 09:00:00'],
        ]);
    }

    public function testCustomerModelReturnsStoredRows(): void
    {
        $this->seedCustomerAndUserTables();

        $model = new CustomerModel();
        $customers = $model->findAll();

        $this->assertIsArray($customers);
        $this->assertGreaterThanOrEqual(1, count($customers));
    }

    public function testUserModelReturnsStoredRows(): void
    {
        $this->seedCustomerAndUserTables();

        $model = new UserModel();
        $users = $model->findAll();

        $this->assertIsArray($users);
        $this->assertGreaterThanOrEqual(1, count($users));
    }
}
